# 重编译配置速查（`gba_recompile --config` 的 TOML）

框架 schema：`docs/TOML_SCHEMA.md`（上游仓库内）。这里只列实际会用到的字段。

## 硬规则

1. **`[identity].sha1` 不匹配 → 直接 abort**。配置绑定到具体二进制修订版，换版本就要换配置。
2. **`[[data_range]]` 不得被控制流到达**。违反 → `control flow enters data_range`，硬错误。
3. **`[[extra_func]]` 与 `[[data_range]]` 不得重叠**；`[[exclude_func]]` 与 `[[extra_func]]`
   同地址是硬错误（意图矛盾）。
4. **`[[extra_func]]` 的 `mode` 必须与该地址实际指令编码一致**（`arm` / `thumb`），
   不一致 → 错误。
5. **条目不是"必须正确"的**：写错地址会生成垃圾代码；`[[data_range]]` 圈太窄会让
   finder 走进字面量池。**漏一个函数只是 miss，好修；把数据当代码是灾难。**

## `[program]`（必需）

| 键 | 类型 | 含义 |
|---|---|---|
| `name` | string | 人类可读标签，出现在日志里 |
| `id` | string | 短 slug，用于输出文件名 |
| `load_address` | int hex | 二进制首字节在内存中的位置（GBA 卡带 = `0x08000000`） |
| `size` | int hex | 字节数，**必须等于文件实际大小** |
| `entry_pc` | int hex | 初始 PC。`gba_scan` 给的 `entry_target` |
| `speculative_literal_harvest` | bool | 默认 `true`。从可达的 PC 相对字面量里猜回调指针 |
| `aot_scan_start` / `aot_scan_end` | int hex | 可选，**半开区间**。限制"回调表/描述符发现"的扫描范围。两者都要给 |
| `static_resume_all` | bool | 默认 `true`。给每条对齐指令都加静态 dispatch 入口（IRQ/SWI 任意指令边界都能恢复） |
| `codegen_shards` | int | 可选 2..256。省略则自适应选 2..64 的 2 的幂。卡带输出**永远不是单文件** |

### `aot_scan_*` 怎么取

它是"回调表发现"的边界，**不是**代码/数据分界线。
给一个**密集代码区**的区间（例如 `0x080000C0` 到首个压缩资源之前），
把压缩图形和大块数据排除在外——schema 原文：
"Keep compressed graphics and other assets outside the executable range."

## `[identity]`（必需）

```toml
[identity]
sha1 = "<小写十六进制 SHA-1>"
md5  = "<可选，交叉校验>"
```

## `[[extra_func]]`

finder 没找到、但控制流能到达的函数入口。

| 键 | 必需 | 含义 |
|---|---|---|
| `addr` | ✔ | 函数首字节地址 |
| `source_addr` | | **ROM 源地址**——用于"运行期被搬到 RAM 的入口"。源码/运行时偏移会沿直接 CFG 边传播 |
| `mode` | ✔ | `"arm"` 或 `"thumb"`，必须与该地址实际编码一致 |
| `resume` | | `true` 表示这是**函数内部的续执行地址**（IRQ/SWI 返回点），会并进外层函数 |
| `name` | | 生成 C 里的函数名，默认 `afunc_XXXXXXXX` / `tfunc_XXXXXXXX` |
| `note` | | 自由文档，不影响生成 |

**去重规则**：finder 与 TOML 都声明同一 (addr, mode) → 只留一条，TOML 的 name/note 胜出；
mode 不一致 → 错误。

**`source_addr` 是 RAM 拷贝场景的关键**。运行时把 ROM 代码拷到 RAM 再跳过去时，
`addr` 是**运行期地址**，`source_addr` 是**ROM 源地址**，
这样生成的代码保留运行期 PC、却从 ROM 源取字节。

## `[[code_copy]]`

运行期 ROM→RAM 的代码拷贝映射。

| 键 | 必需 | 含义 |
|---|---|---|
| `runtime_start` | ✔ | 拷贝完成后的可执行首地址 |
| `source_start` | ✔ | 原始二进制里的源字节首地址 |
| `size` | ✔ | 拷贝字节数 |
| `name` / `note` | | 文档 |

**它本身不创建函数入口**。要声明已知入口得另加 `[[extra_func]]`，
或让 finder 自己去发现跳进该区间的分支。

### 怎么定这三个值

| 值 | 怎么得到 |
|---|---|
| `source_start` | 拷贝例程字面量池里的 ROM 源地址（与 `runtime_start` 成对存放） |
| `runtime_start` | 同一个字面量池里的 RAM 目标地址 |
| `size` | 用「运行期 RAM 快照字节 == ROM 字节」实测的**连续相同长度** |

配 `[[extra_func]]` 时：`addr` = 运行期地址（CPU 实际落点），
`source_addr` = ROM 源地址（指令字节来源）。**两者不可互换。**

完整四步定位法见 `references/troubleshooting.md` §21。

## `[[jump_table]]`

switch 跳转表。表内字节会被**自动排除**在代码解码之外。

| 键 | 必需 | 含义 |
|---|---|---|
| `addr` | ✔ | 表首字节 |
| `stride` | ✔ | 每项字节数（常见 4） |
| `count` | ✔ | 项数 |
| `format` | ✔ | `abs32` / `abs16` / `pcrel_thumb` / `pcrel_arm` / `u8_rel_thumb` / `u16_rel_thumb` |
| `base` | | 仅相对 THUMB 格式：`ADD pc,Rt` 指令地址 + 4 |
| `entries_mode` | ✔ | `"arm"` / `"thumb"` / `"auto"` |
| `name` / `note` | | 文档 |

`entries_mode = "auto"` 按每项值的 bit0 判 ARM/THUMB（BX/BLX 互操作惯例）。
`pcrel_*` 格式的 mode 写死在关键字里，必须与 `entries_mode` 一致。

## `[[data_range]]`

禁止解码为代码的字节区间（半开区间）。

| 键 | 必需 | 含义 |
|---|---|---|
| `start` | ✔ | 首字节 |
| `end` | ✔ | 末字节 + 1 |
| `note` | | 文档 |

**`start < end`；不得与 `[[extra_func]]` 地址重叠；可与 `[[jump_table]]` 的表字节重叠。**

## `[[exclude_func]]`

误判为代码的假阳性入口。

| 键 | 必需 | 含义 |
|---|---|---|
| `addr` | ✔ | 要移除的入口 |
| `reason` | ✔ | 强制作者说明理由 |

**优先级高于 `[[extra_func]]`**；同地址两者都写是硬错误。

## `[[resume_range]]`

一个函数的**内部有多个 IRQ 返回点**时，用一个区间声明，而不是逐个列 resume 别名。

| 键 | 必需 | 含义 |
|---|---|---|
| `start` | ✔ | 真实函数入口 |
| `end` | ✔ | 对齐的独占上界 |
| `mode` | ✔ | `"arm"` / `"thumb"` |
| `note` | | 文档 |

上限 0x1000 字节；必须整体在程序映像或某个 `[[code_copy]]` 运行时区间内。

## `[[thumb_alu_immediate_override]]`

精确到某一条 THUMB 数据处理指令的 PC，替换其立即数（用于常量类 mod）。
**默认无条目** → 立即数保持编译期字面量，生成代码无回调判断、零性能开销。

## `[[mod_function_hook]]`

声明一条**允许被 trusted plugin 替换**的 guest 函数入口。

| 键 | 必需 | 含义 |
|---|---|---|
| `addr` | ✔ | 精确的 guest 函数入口 PC（ARM 需字对齐，THUMB 需半字对齐） |
| `mode` | ✔ | `"arm"` / `"thumb"` |
| `note` | | 文档 |

生成代码里会插入：

```cpp
if (gba_mod_function_entry(0x08003000u, 1, &g_cpu)) return;
```

**条目必须匹配某个真实生成的函数根**，否则是硬 codegen 错误（防止地址漂移导致 hook 静默失效）。

## `[[mod_function_hook]]` 与 `[[extra_func]]` 的关系

- `[[extra_func]]` = **让这个函数被静态编译**
- `[[mod_function_hook]]` = **允许这个函数被运行时替换**

两者可以同时存在（hook 的是被静态编译出来的那个函数）。

## Overlay（可重复 `--config`）

第一个是 base，拥有 `[program]`；后续都是 overlay，合并到 base 之上。
overlay 里出现 `[program]` → abort；overlay 的 `[identity].sha1` 必须等于 base 的。
base 永远赢：base 声明过的 `[[extra_func]]` 地址，overlay 的同名条目被丢弃。

典型用途：机器生成的符号 overlay（贡献成百上千条 `[[data_range]]`）+
人工写的 `game.toml` 合并，而不是互相覆盖。
