# 验证与覆盖率指标

## 1. 三条验证路径

| 路径 | 命令 | 用途 |
|---|---|---|
| **无窗口 + 导出帧** | `--no-window --frames N --dump-png out.png` | 最可靠。不依赖桌面环境，能直接看画面 |
| **TCP 调试服务** | `--tcp`（启动时 **PAUSED**） | 活体检查：可 `continue` / `screenshot` / 查状态 |
| **真实窗口** | 去掉 `--no-window` | 给人玩；需要 SDL2 与交互式桌面 |

TCP 工具（框架自带）：

```powershell
.\build\gbarecomp-src\tools\tcp_screenshot.ps1 -Port 19842 -Out frame.png -Scale 3 -Continue
```

`-Continue` 会先发 `{"cmd":"continue"}`（`--tcp` 实例启动时是暂停的），
再请求 `{"cmd":"screenshot"}` 拿 RGB 帧缓冲解码成 PNG。

## 2. 帧数 ↔ 游戏时间

宿主的 `guest_fps` 通常 **500~900**（无窗口）/ **~600**（窗口）。

| 想看到 | 建议帧数 |
|---|---|
| 启动渐变 | ~3,000 |
| 首个角色立绘 | ~10,000 |
| 剧情文字 | ~20,000 |
| 菜单 | ~60,000 |

`guest_fps × 游戏秒数 = 帧数` → 20000 帧 ≈ 22~40 秒游戏时间。
**跑不到画面先加大帧数，别急着怀疑移植失败。**

## 3. 关键指标

运行结束后 stdout 的几行：

```
final_pc=0x0806112C unmapped=1 io_unhandled=0 steps=4471 cycles=62191750
ppu_vcount=161 ppu_frames=20000 frames_presented=0
pal_nonzero=512/1024 vram_nonzero=40688/98304 oam_nonzero=158/1024
self_heal_coverage=NOT_STATIC dispatch_misses=4 interpreted_insns=3516074
```

| 指标 | 健康值 | 含义 |
|---|---|---|
| `pal_nonzero` | > 0 | 调色板被写过 → PPU 在渲染 |
| `vram_nonzero` | 明显 > 0 | 图形数据写进了 VRAM |
| `oam_nonzero` | > 0 | 有精灵（角色/UI） |
| `frames_presented` | 窗口模式 > 0 | 帧真的送到了屏幕；无窗口模式为 0，属正常 |
| `dispatch_misses` | 越小越好 | 走解释器的不同 PC 数 |
| `interpreted_insns` | 越小越好 | 解释执行的指令总数（衡量"慢"的来源） |
| `unmapped` / `io_unhandled` | 应接近 0 | 未映射访问 / 未处理的 IO |
| `self_heal_coverage` | `FULLY_STATIC` 最好 | `NOT_STATIC`=有桥接；`FULLY_STATIC`=全部静态化，解释器完全没参与 |

`self_heal_coverage=FULLY_STATIC` 通常伴随 `dispatch_misses=0` 与
`interpreted_insns=0`——这是"原生性能等价"的判据，
意味着运行时不再有任何 guest 代码走解释器。

> **注意**：`dispatch_misses=0` 但 `self_heal_coverage=NOT_STATIC` 时，
> 看 `healed_native`——它是 tcc 自愈层的**热缓存残留**，不是覆盖缺口。
> 用 `GBARECOMP_HEAL_CACHE` 指向干净目录冷跑即可，
> 见 `references/troubleshooting.md` §22。

**判定"画面是否真的出来了"**：三项 `*_nonzero` 同时 > 0，且 `--dump-png` 的 PNG 不是纯色。

**判定"是否跑偏"**：`dispatch_misses` 大 → 说明大量 guest 函数没被静态编译，
游戏在解释器里跑，慢且可能行为不对。

## 4. 覆盖率收敛循环

```
跑一轮 → 看 dispatch_misses 与 .frag 提案
      → 卡带地址 → [[extra_func]]
      → RAM 地址 → 先逆向找源地址 → [[code_copy]] (+ [[extra_func]] source_addr)
      → 连串同模式地址 → [[jump_table]]
      → 重新生成 + 重编译 + 重跑
```

**收敛的边际收益**：13 → 4 个 miss 时，`interpreted_insns` 从 12,710,612 降到
3,516,074（-72%）。再往下每个 miss 都要靠逆向找源地址，成本陡增——
但收益也最接近"原生性能"：补齐 RAM 拷贝表后直接到 **0 miss / 0 解释指令**。

**停止条件**：画面与交互正常 + miss 数不再明显下降 → 把残留 PC 写进"剩余缺口清单"交付。
若追求 `FULLY_STATIC`，走 `references/troubleshooting.md` §21 的四步定位法。

### 覆盖率配置（可选）

```powershell
$env:GBARECOMP_STRICT_STATIC = '1'   # 禁止解释器桥接：任何 miss 立刻暴露
$env:GBARECOMP_SELFHEAL_VERBOSE = '1' # 逐 PC 诊断
```

`GBARECOMP_STRICT_STATIC=1` 只在**调试覆盖率**时开——
它会让任何残余 miss 直接失败，游戏跑不起来。调试完记得关掉。

## 5. 交付前的检查清单

- [ ] `gba_scan` 的 `complement_valid=1`、`logo_present=1`（ROM 头自洽）
- [ ] BIOS 与 ROM 都通过哈希校验（日志 `bios_loaded sha1=...` / `rom_loaded sha1=...`）
- [ ] `bios_backend=LLE`（BIOS 走的是重编译路径，不是 HLE 兜底）
- [ ] `save_config` 的 type/size 与用户自己的 `.sav` 尺寸一致
- [ ] `pal_nonzero` / `vram_nonzero` / `oam_nonzero` 均 > 0
- [ ] `--dump-png` 出的 PNG 有实际内容（不是纯色）
- [ ] 窗口模式能创建出可见窗口
- [ ] 存一次档再读回来，数据没坏
- [ ] 残留的 `dispatch_misses` 已写进交付说明

## 6. 常见误判

| 现象 | 别误判成 |
|---|---|
| 画面全白 | 移植失败 —— 可能是 BIOS 没 LLE，或帧数不够 |
| `dispatch_misses` 很大 | 移植失败 —— 可能只是慢；画面正常就能接受 |
| `frames_presented=0` | 没渲染 —— 无窗口模式本就是 0，看 `*_nonzero` |
| `interpreted_insns` 很大 | 逻辑跑错 —— 它只是慢，慢和错是两回事 |
| `unmapped=1` | 致命 —— 多为偶发的未初始化访问，出现在 boot 阶段可容忍 |

## 7. 性能参照

一台 32 核 / 32 GB 的机器（MSVC `/O2`，8 分片并行）：

| 阶段 | 耗时 |
|---|---|
| 框架自建（`gba_recompile` + `gba_scan`） | ~18 s |
| 静态重编译 BIOS（770 个函数） | ~0.1 s |
| 静态重编译 ROM（13,271 个函数 / 103 MB C++ / 8 分片） | ~1 s |
| 编译 8 分片 → 静态库（44 MB） | ~20 s |
| 链接游戏 exe（22.7 MB） | ~40 s |
| 跑 20,000 帧 | ~35 s（guest_fps ≈ 600） |

**整条流水线（不含首次框架自建）≈ 2 分钟。**
所以迭代成本极低，值得多跑几轮不同配置。
