# 排错表：症状 → 原因 → 修法

按"最省时间的诊断顺序"排列。先看第一节的快速分流表。

## 0. 快速分流

| 看到什么 | 跳到 |
|---|---|
| 画面全白 / `runtime_irq: handler did not iret` | §1 |
| `ERROR: control flow enters data_range` | §2 |
| `dispatch_misses` 数字下不去 | §3 |
| `tcc exit -1` | §4 |
| `tcc exit 1` + `include file not found` | §5 |
| `tcc exit 1` + `'g_runtime_resume_pc' undeclared` | §6 |
| `save size N is incompatible with ...` | §7 |
| `error C2440` 初始化 / dispatch table | §8 |
| `__builtin_clz` 找不到标识符 | §9 |
| `.ps1` 报 ParserError | §10 |
| `.ps1` 在中途莫名中断 | §11 |
| 哈希算出来是空的 | §12 |
| exe 找不到 | §13 |
| 画面全白但 `vram_nonzero > 0` | §14 |
| 存档存不进去 / 读出来是乱的 | §15 |

---

## 1. 全白屏 + `runtime_irq: handler did not iret after N dispatches`

**原因**：BIOS 走的是 HLE（软件模拟）路径时，BIOS 的 IRQ 向量（ROM 地址 `0x18`）
没有被静态编译，运行时把它交给解释器，解释器返回后 `iret` 链路断掉，
IRQ handler 永远等不到返回 → 主循环卡死 → PPU 停在空白帧。

**修法**：**静态重编译 BIOS**，让它走 LLE 路径。

```powershell
Copy-Item <user_bios.bin> build\gbarecomp-src\bios\gba_bios.bin -Force
.\gba_recompile.exe --bios build\gbarecomp-src\bios\gba_bios.bin `
  --config build\gbarecomp-src\bios\gba_bios.toml `
  --out build\gbarecomp-src\src\runtime\generated_bios
```

然后**重新 configure**（框架 CMake 靠 `bios_recompiled.cpp` 是否存在来决定链接），
再重新编译。

**验证**：运行日志里应出现
`bios_backend=LLE (recompiled BIOS)` 与 `bios_boot=LLE (real intro)`。
若仍是 `HLE (with LLE fallback)`，说明重编译产物没被链接上。

**副作用**：`bios_boot=LLE (real intro)` 表示会播放真实 BIOS 开机动画，
耗时更多帧才进游戏；`--bios-skip-intro` 可跳过。

---

## 2. `ERROR: control flow enters data_range`

```
ERROR: control flow enters data_range
  data_range:    [0x080B9F80, 0x08600000)   "..."
  entering from: B 0x085CCC04 at PC=0x080000C0 (afunc_080000C0)
```

**原因**：`[[data_range]]` 圈进了控制流实际会到达的地址。

**GBA 的典型陷阱**：**代码与资源是交错的**，不是"前面代码、后面数据"。
实测过一份 ROM 的布局：

| 区间 | 内容 |
|---|---|
| `0x080000C0-0x0803FFFF` | 稀疏（146 个函数）+ 资源起点 |
| `0x08040000-0x080BFFFF` | **主代码**（12,789 个函数，占 99.7%） |
| `0x085C0000-0x085FFFFF` | **启动模块（crt0）**——入口分支目标 `0x085CCC04` 在这里 |
| 其余 | 大块资源 / 数据 |

**修法**：缩小区间，不是删掉配置。原则：
- 只标"确定不是代码"的小块（Logo、头部字段、明确的压缩资源块）
- 入口分支目标、任何被 `[[extra_func]]` 声明的地址，都不能在 data_range 内
- 宁可少标（漏函数 = run 时的 miss，可修），不要多标（假阳性 = 生成垃圾代码，会静默跳飞）

---

## 3. `dispatch_misses` 降不下来

运行结束会打印：

```
self_heal_coverage=NOT_STATIC dispatch_misses=4 interpreted_insns=3516074
  bridged 0x030006A4 (arm) x124032
  bridged 0x080612BC (thumb) x19077
```

同时在运行目录生成 `recomp_master_misses_<code>.toml.frag`，里面是**自动提案**的
`[[extra_func]]` 条目。框架**从不自动合并**，必须人工审核。

**按地址类型分三种处理**：

| 地址形态 | 含义 | 处理 |
|---|---|---|
| `0x08xxxxxx`（ROM 空间） | ROM 里的函数没被自动发现 | 直接抄进 `[[extra_func]]` |
| `0x02xxxxxx` / `0x03xxxxxx`（RAM 空间） | **运行期从 ROM 拷进去的代码** | 要 `[[code_copy]]`（runtime→source 映射），**不能用 `[[extra_func]]`** |
| `0x00xxxxxx`（BIOS 空间） | BIOS 内部 | 属于 `bios/gba_bios.toml`，不该出现在卡带配置里 |

**为什么 RAM 地址不能用 `[[extra_func]]`**：finder 会按 ROM 地址去取字节，
但那个地址在 ROM 里是别的数据 → 生成垃圾 C++ → 可能静默跳进垃圾代码，
**比 miss 危险得多**（schema 原文："Decoding data as code is a false positive — catastrophic"）。

**找 RAM 拷贝源地址的办法**：见 **§21**（四步定位法：RAM 快照 → 字面量池 → 实测 size → 反汇编读函数头）。

**同一模式地址连成串** → 多半是 switch 跳转表，用一条 `[[jump_table]]` 覆盖整表，
比逐个 `[[extra_func]]` 好。框架的 discovery summary 会打印
`auto_jt <addr> count=<n> stride=<n> site=<pc>` 这样的线索。

**收敛目标**：画面与交互正常即可，残留桥接 PC 记进"剩余缺口清单"。
但 0 miss 是可达的——卡带地址靠 `[[extra_func]]`，RAM 地址靠 `[[code_copy]]`（见 §21）。

---

## 4. `tcc exit -1`

**原因**：自愈层要用 TinyCC 现场编译被桥接的函数，但 TCC 没就位。
框架在 `<exe_dir>/overlay_toolchain/tcc/tcc.exe` 找它。

```powershell
.\build\gbarecomp-src\tools\fetch_tcc.ps1 -Toolchain <exe_dir>\overlay_toolchain
```

也会找 `PATH` 上的 `tcc`。注意 `fetch_tcc.ps1` 需要能访问
`download.savannah.gnu.org`。

---

## 5. `tcc exit 1` + `include file not found`（`../../external/arm-recomp-core/...`）

**原因**：main 分支的 `src/armv4t/runtime_arm_types.h` 用**相对路径**引用子模块：

```c
#include "../../external/arm-recomp-core/profiles/armv4t_gba/runtime_arm_types.h"
```

`fetch_tcc.ps1` 把头文件"拍平"到 `overlay_toolchain/include/`，相对路径就断了。

**修法**：在 exe 目录旁还原这个目录结构：

```powershell
$arc = "<exe_dir>\external\arm-recomp-core\profiles\armv4t_gba"
New-Item -ItemType Directory -Force -Path $arc | Out-Null
Copy-Item build\gbarecomp-src\external\arm-recomp-core\profiles\armv4t_gba\runtime_arm_types.h `
          "$arc\runtime_arm_types.h" -Force
```

`overlay_toolchain/include/runtime_arm_types.h` 里的 `../../` 从
`overlay_toolchain/include/` 出发 → `<exe_dir>/external/...`，正好对上。

---

## 6. `tcc exit 1` + `'g_runtime_resume_pc' undeclared`

**原因**：main 分支的 overlay shim 与 overlay emitter 不自洽——
emitter 生成的 C 引用了 `g_runtime_resume_pc`（声明在 `runtime_arm.h`），
但暂存的 5 个 overlay 头里没有 `runtime_arm.h`。

**修法（按成本排序）**：
1. 优先走 §3 的正路：把这些 PC 补进 `[[extra_func]]`，让它们**静态**编译，
   根本不走 overlay 层
2. 实在要留 overlay：把 `runtime_arm.h` 也拷进 `overlay_toolchain/include/`，
   并让暂存目录结构满足它的相对 include

---

## 7. `save size N is incompatible with <type> (expected ...)`

**原因**：框架对每种存档芯片的**有效尺寸是固定的白名单**：

| type | 有效字节数 |
|---|---|
| `sram` | 32768 |
| `eeprom` | 512 或 8192 |
| `flash512` | 65536 |
| `flash1m` | 131072 |

`gba_scan` 常常返回 `save_type=unknown`（ROM 里没有标准 SDK 签名）。
**判据**：看用户自己的 `.sav` 文件多大，就选哪个 type。
32768 字节 → `sram`；8192 → `eeprom`；65536 → `flash512`；131072 → `flash1m`。

在 `game.toml` 的 `[save]` 段同时写 `type` 和 `size`：

```toml
[save]
type = "sram"
size = 32768
```

---

## 8. `error C2440: "初始化": 无法从 "initializer list" 转换为 "int"`（dispatch table）

**原因**：**生成码与框架头文件不是同一版本**。dispatch table 结构体字段数变了，
新生成的初始化列表比旧头文件的结构体多 → 溢出成 "int"。

**修法**：两者都用同一份框架检出（同一 commit）重新生成 + 重新编译。
最省事的做法：框架自建一次（步骤 1），生成用自建的 `gba_recompile.exe`，
框架源码也用同一个 clone。

---

## 9. `__builtin_clz: 找不到标识符`（MSVC）

**原因**：框架 main 分支的 `src/runtime/bios_hle.cpp` 用了 GCC/LLVM 的 `__builtin_clz`。
实测：MSVC 19.44 的 `__builtin_clz` **只在 C 模式（.c）可用，C++ 模式（.cpp）不可用**。

**修法**：给框架目标加一个 force-include 的兼容头。
完整内容见 `references/build-setup.md` 的「MSVC shim」一节。

**写这个 shim 时的三条硬约束**（每条都对应一个真实踩过的坑）：

1. **不能用同名函数**。C 模式下 `intrin.h` 已声明 `__builtin_clz`，
   重定义变成重复声明，函数体被当成文件作用域裸块 → 一堆误导性错误
   （`C2059 语法错误:if`、`C2365 _BitScanReverse 重定义`…）
2. **不能用 `inline` / `static_cast`**。`/FI` 会把头文件插到目标里**每一个** TU 顶部，
   包括 `.c` 文件；MSVC 默认按 C89 编译 `.c`，两者都不是 C89 关键字
3. **头文件必须是纯 ASCII**。MSVC 按系统码页（936/GBK）读源文件，
   非 ASCII 注释会被误解码并破坏预处理器状态（`#if` 不再是指令），
   报错行号完全对不上文件内容 —— 这是最难查的一类

---

## 10. `.ps1` 报 `ParserError`（"表达式或语句中包含意外的标记"）

**原因**：脚本存成了 **UTF-8 无 BOM**。PowerShell 5.1 会按 ANSI(936/GBK) 解码，
中文注释的乱码吃掉引号。

**修法**：存成 **UTF-8 with BOM**。用 Edit/Write 工具改完后要确认 BOM 还在：

```powershell
$b = [IO.File]::ReadAllBytes($p)
$b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF   # 必须为 True
```

补 BOM：

```powershell
$t = [IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText($p, $t, (New-Object System.Text.UTF8Encoding($true)))
```

**同一个坑也适用于 C/C++ 源文件**：MSVC 会认 BOM 并按 UTF-8 读，没有 BOM 就按 GBK 读。
含中文注释的 `.cpp` 建议一律带 BOM。

---

## 11. `.ps1` 跑到一半莫名中断（报 NativeCommandError）

**原因**：PowerShell 5.1 下 `$ErrorActionPreference='Stop'` 时，
**原生命令只要往 stderr 写任何一行**（哪怕只是 warning）就会变成终止性错误。

框架工具的典型 warning（**退出码是 0，产物完全正常**）：

```
[finder] callback byte-domain call-site analysis budget exhausted; additional contexts remain unexamined
```

**修法**：调用原生命令期间把错误偏好降为 `Continue`，**只看 `$LASTEXITCODE`**：

```powershell
$prev = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try {
    $output = & $FilePath @Arguments 2>&1
    $code = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $prev
}
```

`scripts/build-recomp.ps1` 里的 `Invoke-Native` 就是这个封装。

---

## 12. 哈希算出来是空的

**原因**：`Get-FileHash -Path` 把 `[` `]` 当**通配符**。
游戏文件名里带 `[熊组]` 这类方括号时会**静默返回空**（不报错）。

**修法**：用 `-LiteralPath`。

```powershell
Get-FileHash -LiteralPath 'C:\...\火影忍者 - 木叶战记[熊组](v1.3)(简)(JP)(48Mb).gba' -Algorithm SHA1
```

---

## 13. 编译成功但找不到 exe

**原因**：VS 多配置生成器把可执行文件放在 `<build>/Release/`（多配置）或
`<build>/x64/Release/`，不是 `<build>/`。

**修法**：`Get-ChildItem <build> -Recurse -Filter '*.exe'` 找。

---

## 14. 画面全白但 `vram_nonzero > 0`

**原因**：帧数不够，游戏还没走到出画面的时刻。

**修法**：换算帧数——宿主 `guest_fps` 通常 500~900，
**20000 帧 ≈ 22~40 秒游戏时间**。实测：3000 帧还是加载渐变，
10000 帧才出现角色立绘。直接用 `--frames 60000` 之类的大值再试。

---

## 15. 存档存不进去 / 读出来是乱的

**原因**：存档芯片类型或尺寸不对（见 §7），或游戏用的是 SRAM 而配置成了 EEPROM。

**附加检查**：运行时日志的 `save_config source=... type=... size=...` 一行，
和你 `game.toml` 里写的对不上就说明配置没被读到——检查 `--config` 参数或
`opts.launcher_game_config` 指向的文件名是否与实际放置位置一致。

---

## 16. BIOS 语料"配了但没链接上"（静默退回 stub）

**现象**：日志里 `bios_backend=HLE (with LLE fallback)`，
而且 `src/runtime/generated_bios/bios_recompiled.cpp` **明明存在**。

**原因**：框架在自己的 `CMakeLists.txt` 里用
`if(EXISTS ${GBARECOMP_GENERATED_BIOS_DIR}/bios_recompiled.cpp)` 决定链接真语料还是
placeholder stub。这个判断发生在 **`add_subdirectory()` 期间**——
你把 `GBARECOMP_GENERATED_BIOS_DIR` 设晚了，框架已经处理完了，就静默选了 stub。

**修法**：把 cache 变量写在 `add_subdirectory()` **之前**：

```cmake
set(GBARECOMP_GENERATED_BIOS_DIR "${CMAKE_CURRENT_SOURCE_DIR}/generated_bios"
    CACHE PATH "locally recompiled BIOS sources")
add_subdirectory("${GBARECOMP_ROOT}" gbarecomp_build EXCLUDE_FROM_ALL)
```

设完要**重新 configure**（不是只重新 build）。

---

## 17. RAM 区（IWRAM）缺口默认不自动自愈

**现象**：`0x03xxxxxx` / `0x02xxxxxx` 的 PC 一直走解释器，
即使 TCC 已经暂存、`tcc` 也能编译 ROM 区的函数。

**原因**：RAM 区的自愈 overlay 路径由 `GBARECOMP_RAM_OVERLAY_HEAL` 开关控制，
默认不开。

**修法**：调试时打开

```powershell
$env:GBARECOMP_RAM_OVERLAY_HEAL = '1'
```

再跑一次看缺口是否收敛。**这只是调试开关**——正式发布前要确认
overlay 编译出来的行为与静态语料一致。

---

## 18. overlay 编译成功但宿主解析不到符号

**现象**：tcc 编译 overlay DLL 成功，但运行时行为不对 / 崩溃。

**原因**：overlay DLL 里的符号要么走 `GbaOverlayCallbacks` 回调结构体，
要么走 `extern` 引用宿主导出。**宿主 exe 默认没有导出表**，
所以 `extern` 引用解析不到。

**修法**（两条路）：
1. 给 overlay shim 补一个 resume_pc 通道（框架 overlay ABI 加字段 + 升版本号）——改动在框架侧
2. 让宿主导出该符号（`/EXPORT` + shim 里 `extern "C"` 声明）——改动在游戏侧

**根因值得记住**：overlay ABI 与 overlay emitter 之间的版本漂移。
某框架版本里 emitter 生成了引用 `g_runtime_resume_pc` 的代码，
而 shim 没有对应通道 → `tcc exit 1: 'g_runtime_resume_pc' undeclared`。
遇到这个具体报错，先看 overlay shim 有没有对应字段，而不是去改 tcc。

---

## 19. `Tee-Object` 没有 `-Encoding` 参数

**现象**：`Tee-Object : 找不到接受参数 '-Encoding' 的实际参数`。

**原因**：PowerShell 5.1 的 `Tee-Object` 只有 `-FilePath`，没有 `-Encoding`。

**修法**：用 `Out-File -Encoding UTF8`（或 `Add-Content -Encoding UTF8`）代替。

---

## 20. 构建时间突然翻倍

**现象**：同样的分片，构建时间比预期多一倍。

**原因**：同一批 `recompiled_*.cpp` 被编了两次——一次进 `gbarecomp_game` 静态库，
又一次直接进 exe 的源文件列表。

**修法**：二选一，不要都做。见 `references/build-setup.md` 的 CMakeLists 模板。

---

## 21. 残留 PC 落在 RAM 地址：定位 ROM→IWRAM 拷贝表

**现象**：运行日志里出现

```
bridged 0x030006A4 (arm) x124032
bridged 0x03005CE8 (arm) x124032
```

地址在 `0x02xxxxxx` / `0x03xxxxxx`（EWRAM/IWRAM），**不是 ROM 地址**。

**判定**：这类 PC **不是"找不到静态实现"**，而是游戏在启动时把 ROM 里的一段代码
**重定位到 IWRAM**（GBA 上 IWRAM 比卡带快），再通过 IWRAM 里的函数指针表间接调用。
重编译器按卡带地址去取字节当然取不到 → 退化成解释器桥接。

> **不要**为此改 overlay ABI、也不要给 exe 加 `/EXPORT`（见 §18）——
> 那是"ABI 缺 resume_pc 通道"的解法，不适用于本症状。

### 四步定位法

**第 1 步：拿到运行期 RAM 快照。**
用宿主自己的状态转储，不要只依赖外部模拟器的快照：

```powershell
.\build\gbarecomp-build\Release\NarutoKonohaSenkiRecomp.exe `
    --rom rom\base.gba --bios bios\gba_bios.bin --frames 20000 `
    --no-window --dump-state state_20000.json
```

快照里含 IWRAM 32 KB 与 EWRAM 32 KB 的**运行期内容**——也就是"拷贝完成后的字节"。

**第 2 步：从 verbose 自愈日志拿到跳转来源。**

```powershell
$env:GBARECOMP_SELFHEAL_VERBOSE = '1'
```

日志会打出形如 `for pc=0x03005CE8; LR=0x03000694 (fallback stop)` 的行——
`LR` 就是**发起跳转的 IWRAM 地址**，拿它当新的检索起点。

**第 3 步：在 ROM 里找拷贝例程的字面量池，成对读出 `(ROM 源, IWRAM 目标)`。**
拷贝例程是 `memcpy` 风格的一串调用，源指针/目标指针/长度都在它的**字面量池**里。
两个相邻的字面量槽就是一对 `(ROM 源地址, IWRAM 目标地址)`。

> **坑**：这段例程多半是 **THUMB** 不是 ARM。用 ARM 反汇编会得到
> `movweq` / `strhi` 之类的垃圾，看起来像"数据不对"，其实是指令集选错了。
> 判据是 bit0：函数指针最低位为 1 = THUMB。

**第 4 步：用「RAM 字节 == ROM 字节」实测每张表的 size。**
给定 `(runtime_start, source_start)`，逐字节比 RAM 快照与 ROM，
**连续相同的那一段长度就是 `size`**。逐 16 字节统计匹配率更稳。

> **坑**：全零区域会让字节搜索命中上百万个位置，必须先判零。
> 另外"RAM 的零 == ROM 的零"是假阳性拷贝，要逐条复核。

### 声明配置

```toml
[[code_copy]]
runtime_start = 0x03000680
source_start  = 0x080004C8
size          = 0x00000200
name = "iwram_stub_module_a"
note  = "relocated stub module; 512 B verified byte-identical"

[[extra_func]]
addr        = 0x03000680     # CPU 实际落到的运行期地址
source_addr = 0x080004C8     # 指令字节来自的 ROM 地址
mode = "arm"
name = "iwram_trampoline_080004C8"
```

`[[code_copy]]` 声明**区间映射**，`[[extra_func]]` 声明**函数入口**，
两者要配套：前者让生成代码"保留运行期 PC、却从 ROM 源取字节"。

模块里的函数头靠反汇编读出（同一个 ROM 段可能被装到**多个** IWRAM 位置，
所以一个 source 往往对应多个 runtime 入口）：

| ROM | IWRAM 落点 | 形态 |
|---|---|---|
| `0x080004C8` | `0x03000680` | 跳板：`ldr r2,[pc]; ldr r1,[r2]; mov lr,pc; bx r1` |
| `0x080004DC` | `0x03000694` | 同上 |
| `0x080004FC` | `0x030006B4` | 往 `0x03007FF8` 写半字 2（BIOS hook 开关） |
| `0x080005AC` | `0x03000930` | 算术 helper |
| `0x08000638` | `0x03005CE8` | 表查找 helper |

**注意**：同一个 ROM 模块常被装到**两个以上** IWRAM 位置（热路径做两份），
只补其中一个运行期地址，另一个会继续报 miss。

### 实测收益

补齐 4 条 `[[code_copy]]` + 12 条 `[[extra_func]].source_addr` 之后：

| 指标 | 之前 | 之后 |
|---|---|---|
| `dispatch_misses` | 4（基线 13） | **0** |
| `interpreted_insns` | 3,516,074（基线 12,710,612） | **0** |
| `self_heal_coverage` | `NOT_STATIC` | **`FULLY_STATIC`** |
| `guest_fps` | 547 | 603 |
| 静态函数数 | 13,254 | 13,271 |

**成本**：这是整个流程里最贵的一步——它要求真正的逆向（反汇编 + 字节比对），
不是加几行配置。**画面正常就可以停在这里**，把残留 PC 写进交付说明即可。

> **工具提示**：框架 `tools/_vendor/capstone/` 里只带了 `libcapstone.dylib`（macOS），
> Windows 上 `import capstone` 直接 `ImportError`。`pip install capstone` 即可。
> 反汇编脚本建议「优先用已安装的 capstone，失败再回退 vendor 目录」。

---

## 22. `dispatch_misses=0` 但 `self_heal_coverage` 仍报 `NOT_STATIC`

**现象**：覆盖率已经打满了，日志却是

```
self_heal_coverage=NOT_STATIC dispatch_misses=0 interpreted_insns=0 healed_native=1
```

**原因**：**不是覆盖缺口，是 tcc 自愈层的热缓存残留**。框架源码里的判据是：

```cpp
const bool fully_static = g_misses.empty() && healed == 0 && g_interp_insns == 0;
```

上一轮跑留下的 overlay 产物被热缓存加载（`warm_loaded=1`），
框架按注释里的定义「warm cache heals with zero misses but is still NOT fully static」
把它算成非全静态。

**修法**：把自愈缓存指到一个干净目录再跑（**不要**去删旧缓存目录）：

```powershell
$env:GBARECOMP_HEAL_CACHE = 'heal_cache_clean'
```

冷缓存重跑 → `self_heal_coverage=FULLY_STATIC dispatch_misses=0 interpreted_insns=0 healed_native=0`。

**判据**：看 `healed_native`。
`healed_native=1` 而 `dispatch_misses=0` → 缓存问题，不是覆盖问题；
`healed_native>0` 且 `dispatch_misses>0` → 真有缺口。

---

## 23. Stage-2 自愈层在 Windows 上是断的（上游框架缺陷）

**现象**：日志里出现

```
self_heal: sync compile FAILED for 0x030006A4 (arm): tcc exit 1 compiling …_a.c
```

缓存目录里的 `.log` 写着：

```
tcc: error: undefined symbol 'g_runtime_resume_pc'
```

（更早的版本是 `'g_runtime_resume_pc' undeclared` —— 那是「缺声明」；
  变成「undefined symbol」说明声明有了，但**链接期**解析不到。）

**为什么坏**：Stage-2 自愈层把「被桥接的函数」现场编译成 DLL 加载进宿主进程。
框架的 emitter 给「带函数内续执行点」的函数生成 alias 路由前导码，
其中引用宿主全局 `g_runtime_resume_pc`。静态语料有 `runtime_arm.h` 的声明，
**overlay 用的 shim 没有**。就算补上声明，Windows PE 还有第二道墙：
overlay 是 DLL，访问宿主符号只能走**导入表**，而导入表需要 (模块名, 符号名)——
框架的 tcc 命令行既不带宿主 exe，声明也没有 `__declspec(dllimport)`，
宿主 exe 自己还没有导出表。

**实测边界矩阵**（把框架生成的 overlay `.c` 和编译日志从自愈缓存里捞出来试）：

| 声明 | 命令行带宿主 exe | 结果 |
|---|---|---|
| 无 | 否 | `'g_runtime_resume_pc' undeclared`（编译期） |
| 有（无 dllimport） | 否 | `undefined symbol 'g_runtime_resume_pc'` |
| 有（无 dllimport） | 是 | `undefined symbol 'g_runtime_resume_pc', missing __declspec(dllimport)?` |
| 有（`__declspec(dllimport)`） | 是 | **链接成功**；`dumpbin /imports` 显示 `<宿主 exe>` / `g_runtime_resume_pc` |

**修法：三件套，缺一不可**

| 环节 | 归属 | 做法 |
|---|---|---|
| shim 声明带 `__declspec(dllimport)` | 你的工程 | 在**暂存副本** `<exe>/overlay_toolchain/include/overlay_runtime_arm.h` 上打补丁。框架本来就提供摊平机制（`tools/fetch_tcc.ps1`），运行时在 `GBARECOMP_HEAL_BACKEND=auto-no-gcc` 下用这份副本——对上游零侵入、可随构建重新生成、幂等 |
| 宿主 exe 导出该符号 | 你的工程 | `CMakeLists.txt` 的 `target_link_options(<exe> PRIVATE /EXPORT:g_runtime_resume_pc)` |
| tcc/gcc 命令行带宿主 exe | 框架 | 用 `scripts/patch-overlay-host-link.ps1` 给 `src/runtime/overlay_compile.cpp` 打补丁。幂等；三个锚点任一对不上就抛错，不静默跳过 |

> **为什么不在框架仓库里改**：`gbarecomp-src` 是第三方检出。直接改它的源码会在下次
> 重新 clone 时丢失，也会让本地产物与上游状态不一致。把补丁逻辑收在你的工程里，
> 由构建脚本每次 clone 后调用即可。框架的 runtime 库是在你的工程里通过
> `add_subdirectory` 编译的，所以补丁应用后只需重建你的工程，框架工具不用重建。

**实测收益**（用去掉 `[[code_copy]]` 的对照配置强制制造 4 个缺口）：

| 指标 | 修复前 | 修复后 |
|---|---|---|
| `failed`（overlay 编译失败） | 4 | **0** |
| `healed_native` | 0 | **6** |
| `interpreted_insns` | 3,516,074 | **0** |
| `native_calls` | 0 | **602,065** |

→ 即使静态覆盖有缺口，自愈层也能把缺口**全部原生化**，解释器一条指令都不执行。
覆盖打满时这条路根本不会被触发，但它是工程对未来新缺口的兜底。

> 顺带：`GBARECOMP_RAM_OVERLAY_HEAL=1` 必须显式打开，
> 否则 RAM 区的缺口**默认不自动自愈**（框架静默走解释器桥接且不打印错误）。

