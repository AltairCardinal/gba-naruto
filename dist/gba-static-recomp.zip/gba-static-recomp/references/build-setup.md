# 工具链搭建与工程模板

## 目录

- [1. 依赖清单](#1-依赖清单)
- [2. 框架获取与自建](#2-框架获取与自建)
- [3. SDL2](#3-sdl2)
- [4. MSVC shim（框架 main 分支必需）](#4-msvc-shim框架-main-分支必需)
- [5. game repo 模板](#5-game-repo-模板)
- [6. game.toml 模板](#6-gametoml-模板)
- [7. TCC 与子模块目录结构](#7-tcc-与子模块目录结构)
- [8. Linux / macOS 差异](#8-linux--macos-差异)

---

## 1. 依赖清单

| 依赖 | 必需 | 说明 |
|---|---|---|
| C++17/20 编译器 + CMake ≥ 3.20 | ✔ | 框架与生成码都用 C++20 |
| Git | ✔ | 拉框架与子模块 |
| SDL2 开发库 | 否 | 缺了 `host_window` 退化成 stub，**只能无窗口跑**（用 `--dump-png` 仍可验证画面） |
| GBA BIOS dump | ✔（运行时） | 用户自己主机导出，16 KB，SHA-1 `300c20df6731a33952ded8c436f7f186d25d3492` |
| TinyCC | 否 | 自愈层现场编译用；缺失时桥接 PC 走解释器（慢但能跑） |
| Java / JDK | ✘ | 不需要（apktool 那种 Android 打包才要） |

## 2. 框架获取与自建

```powershell
git clone --depth 1 https://github.com/mstan/gbarecomp.git build\gbarecomp-src
git -C build\gbarecomp-src submodule update --init --depth 1 --recursive
```

子模块（`external/`）：

| 路径 | 来源 | 用途 |
|---|---|---|
| `arm-recomp-core` | 框架仓内（相对路径 `../arm-recomp-core.git`） | ARM 核心类型头，被 `runtime_arm_types.h` 相对引用 |
| `recomp-net` | RetroPortingToolKit | 回滚联机 |
| `rbengine` | RetroPortingToolKit | 回滚引擎 |
| `platform/android/third_party/SDL` | mstan/SDL | Android 用 |

自建（MSVC 多配置）：

```powershell
$cmake = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
& $cmake -S build\gbarecomp-src -B build\gbarecomp-src\build-vs -A x64
& $cmake --build build\gbarecomp-src\build-vs --config Release --target gba_recompile gba_scan --parallel 16
```

**为什么要自建而不是用预编译 CLI**：main 分支比 v0.2.0 发布版多识别约 1000 个函数、
自动发现 1300+ 个 RAM 拷贝模板。另外 `gba_recompile.exe --out` 与
`gbarecomp.exe build --output` 的**输出布局不同**（前者直接放根目录，后者放 `generated/` 并附
CMake 脚手架），别混用。

MSYS2 / MinGW 也是上游推荐路径（`pacman -S mingw-w64-x86_64-toolchain mingw-w64-x86_64-cmake
mingw-w64-x86_64-ninja mingw-w64-x86_64-SDL2`），能省掉下面的 shim。

## 3. SDL2

官方 VC 开发包解压后：

- 头文件：`<pkg>/include`
- 库：`<pkg>/lib/x64/SDL2.lib`
- 运行时：`<pkg>/lib/x64/SDL2.dll`（**要拷到 exe 同目录**）

CMake 通过两个 cache 变量喂给框架：

```powershell
& $cmake -S . -B build -A x64 `
  -DSDL2_INCLUDE_DIR='<pkg>/include' `
  -DSDL2_LIBRARY='<pkg>/lib/x64/SDL2.lib'
```

框架找不到 SDL2 时只会在 configure 输出里打印一行
`gbarecomp: SDL2 NOT found — host_window will stub out`，**不报错**。
所以务必自己确认这一行。

## 4. MSVC shim（框架 main 分支必需）

框架 `src/runtime/bios_hle.cpp` 用了 GCC 的 `__builtin_clz`。实测：
**MSVC 19.44 只在 C 模式（.c）提供它，C++ 模式（.cpp）没有** →
`error C3861: "__builtin_clz": 找不到标识符`。

**修法**：给 `gbarecomp_runtime` 目标加一个 force-include 的头。

`compat/msvc_builtin_clz.h`（**必须纯 ASCII**）：

```c
#pragma once

#if defined(_MSC_VER)

#include <intrin.h>

#pragma warning(push)
#pragma warning(disable : 4505) /* unreferenced static function */

static unsigned int gbarecomp_msvc_clz32(unsigned int v) {
    unsigned long index = 0;
    if (v == 0u) {
        return 32u;
    }
    _BitScanReverse(&index, v);
    return 31u - (unsigned int)index;
}

#define __builtin_clz(x) gbarecomp_msvc_clz32((unsigned int)(x))

#pragma warning(pop)

#endif /* _MSC_VER */
```

在父工程的 `CMakeLists.txt` 里：

```cmake
add_subdirectory("${GBARECOMP_ROOT}" gbarecomp_build EXCLUDE_FROM_ALL)

if(MSVC)
    target_compile_options(gbarecomp_runtime PRIVATE
        "/FI${CMAKE_CURRENT_SOURCE_DIR}/compat/msvc_builtin_clz.h")
endif()
```

**为什么必须是宏而不是同名函数**：C 模式下 `intrin.h` 已声明 `__builtin_clz`，
重定义会变成重复声明，函数体被当成文件作用域裸块，产生
`C2059 语法错误:if` / `C2365 _BitScanReverse 重定义` 这类完全误导的错误。

**为什么不能用 `inline` / `static_cast`**：`/FI` 会把头插到目标里**每一个** TU 顶部，
包括 `.c`；MSVC 默认按 C89 编译 `.c`，这两个都不是 C89 关键字。

**为什么必须纯 ASCII**：MSVC 按系统码页（936/GBK）读源文件，非 ASCII 注释会被误解码，
可能产生 0x5C 尾字节 → 预处理把下一行当续行 → `#if` 不再是指令 →
报错行号与文件内容完全对不上。**这是本流程最难查的一类失败**。

## 5. game repo 模板

### `CMakeLists.txt`

```cmake
cmake_minimum_required(VERSION 3.20)
project(MyGameRecomp C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(GBARECOMP_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/gbarecomp"
    CACHE PATH "gbarecomp platform core (git submodule)")
set(GENERATED_DIR "${CMAKE_CURRENT_SOURCE_DIR}/generated"
    CACHE PATH "recompiled C++ output")

# BIOS 重编译产物目录。**必须在 add_subdirectory 之前设置**：
# 框架在自己的 CMakeLists 里用 if(EXISTS .../bios_recompiled.cpp) 决定链接
# 真正的 BIOS 语料还是 placeholder stub——设晚了就会静默退回 stub，
# 表现为 IRQ 循环 + 全白屏。
# 省略此项则用框架默认：${GBARECOMP_ROOT}/src/runtime/generated_bios
# set(GBARECOMP_GENERATED_BIOS_DIR
#     "${CMAKE_CURRENT_SOURCE_DIR}/generated_bios"
#     CACHE PATH "locally recompiled BIOS sources")

add_subdirectory("${GBARECOMP_ROOT}" gbarecomp_build EXCLUDE_FROM_ALL)

file(GLOB GEN_SOURCES CONFIGURE_DEPENDS "${GENERATED_DIR}/recompiled_*.cpp")
add_library(gbarecomp_game STATIC
    ${GEN_SOURCES} "${GENERATED_DIR}/dispatch_table.cpp")
target_include_directories(gbarecomp_game PRIVATE
    "${GENERATED_DIR}" "${GBARECOMP_ROOT}/src/armv4t")
set_target_properties(gbarecomp_game PROPERTIES CXX_STANDARD 20)
# 分片每个 11-14 MB，不开 /bigobj 会 COFF 段数超限（C1128）。
if(MSVC)
    target_compile_options(gbarecomp_game PRIVATE /bigobj)
endif()

add_executable(MyGameRecomp src/main.cpp)
target_include_directories(MyGameRecomp PRIVATE
    "${GBARECOMP_ROOT}/src/armv4t" "${GBARECOMP_ROOT}/src/gba"
    "${GBARECOMP_ROOT}/src/runtime" "${GBARECOMP_ROOT}/src/debug" src)
target_link_libraries(MyGameRecomp PRIVATE
    gbarecomp_game gbarecomp_runtime gbarecomp_debug gbarecomp_gba gbarecomp_armv4t)
target_compile_definitions(MyGameRecomp PRIVATE
    GBARECOMP_DEFAULT_DEBUG_PORT=19842
    GBARECOMP_WINDOW_TITLE="MyGameRecomp"
    GBARECOMP_DEFAULT_GAME_CONFIG="game.toml")
set_target_properties(MyGameRecomp PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}")

if(MSVC)
    target_link_options(MyGameRecomp PRIVATE /STACK:16777216)
elseif(MINGW OR WIN32 OR CMAKE_SYSTEM_NAME STREQUAL "MSYS")
    target_link_options(MyGameRecomp PRIVATE -Wl,--stack,16777216)
endif()

# 导出 Stage-2 自愈层要用的宿主符号。
# overlay 是 DLL，要访问宿主进程里的 g_runtime_resume_pc 只能走导入表，
# 而 exe 默认没有导出表 → 必须显式导出。
# 详见 references/troubleshooting.md §23 与 scripts/patch-overlay-host-link.ps1。
if(MSVC)
    target_link_options(MyGameRecomp PRIVATE /EXPORT:g_runtime_resume_pc)
endif()
```

**不要把同一批分片编两遍。** 如果既建 `gbarecomp_game` 静态库、又把
`recompiled_*.cpp` 直接加进 exe 的源文件，100 MB 的 C++ 会被编译两次，
构建时间翻倍。要么走静态库、要么直接进 exe，**二选一**。

**`/STACK` 16 MB 必须给**：游戏递归深、栈帧大，MSVC 默认 1 MB 栈会直接崩。

### `src/main.cpp`

```cpp
#include <cstdio>
#include <cstring>
#include "runtime.h"

int main(int argc, char** argv) {
    gbarecomp::RunOptions opts;
    opts.builtin_game_name = "My Game";
    opts.builtin_rom_sha1  = "<ROM SHA-1>";
    opts.mod_game_id       = "my-game";
    opts.launcher_region   = "USA";
    opts.launcher_game_config = "game.toml";
    return gbarecomp::run_game(argc, argv, opts);
}
```

命令行：`MyGameRecomp [--bios <path>] [--rom <path>] [game.toml]`。
三者的缺省值都从 `game.toml` 取。

**要接 mod 目录**还需要 `GBARECOMP_ENABLE_MODS=ON`（默认 OFF），
以及 `opts.mod_game_id` 指向一个存在的 catalog。

## 6. `game.toml` 模板

```toml
[game]
name           = "My Game"
short_name     = "my_game"
default_region = "usa"

[bios]
path = "bios/gba_bios.bin"
sha1 = "300c20df6731a33952ded8c436f7f186d25d3492"

[rom]
path = "roms/my_game.gba"
sha1 = "<ROM SHA-1>"

[recompiler]
entry_point = "0x080000C0"
seeds       = "symbols/imported_symbols.tsv"
out_dir     = "generated"
strict      = true

[save]
type = "sram"        # sram | flash512 | flash1m | eeprom
size = 32768         # 见 references/config-schema.md 的尺寸表

[runtime]
debug_port   = 19842
window_title = "MyGameRecomp"

[video]
screen = "raw"       # raw | unlit | frontlit | backlit | classic
view_width = 240     # >240 需要游戏自己声明 max_view_width

[audio]
shadow = true

[functions]
arm   = []
thumb = []
```

## 7. TCC 与子模块目录结构

```powershell
# 拉取并暂存 TinyCC
.\build\gbarecomp-src\tools\fetch_tcc.ps1 -Toolchain <exe_dir>\overlay_toolchain

# 还原子模块相对目录（main 分支的 runtime_arm_types.h 用 ../../external/... 引用）
$arc = "<exe_dir>\external\arm-recomp-core\profiles\armv4t_gba"
New-Item -ItemType Directory -Force -Path $arc | Out-Null
Copy-Item build\gbarecomp-src\external\arm-recomp-core\profiles\armv4t_gba\runtime_arm_types.h `
          "$arc\runtime_arm_types.h" -Force
```

`fetch_tcc.ps1` 的下载源是 `download.savannah.gnu.org`（tcc 0.9.27 win64）；
网络不通时可手工下同样的 zip，解压后确保 `<overlay_toolchain>/tcc/tcc.exe` 存在。

## 8. Linux / macOS 差异

| 项 | Windows | Linux / macOS |
|---|---|---|
| 编译器 | MSVC（需 shim）或 MSYS2 MinGW（不需 shim） | clang/gcc（不需 shim） |
| SDL2 | 官方 VC 包，`SDL2.dll` 拷到 exe 旁 | `libsdl2-dev` / Homebrew SDL2 |
| 生成目录 | `<build>/Release/`（多配置） | `<build>/`（单配置） |
| 栈大小 | `/STACK:16777216` | `-Wl,--stack,16777216` |
| PowerShell 陷阱 | BOM + stderr 终止性错误 | 不适用 |
| hash 命令 | `Get-FileHash -LiteralPath` | `sha1sum` |
